USE student_management;

DELIMITER //

CREATE PROCEDURE GetAllStudents()
BEGIN
    SELECT * FROM students;
END //

DELIMITER ;

CALL GetAllStudents();

DELIMITER //

CREATE PROCEDURE GetStudentsByCity(IN city_name VARCHAR(50))
BEGIN
    SELECT *
    FROM students
    WHERE city = city_name;
END //

DELIMITER ;

CALL GetStudentsByCity('Lahore');

-- Practice: create these yourself
-- 1. Procedure to find a student by student_id
-- 2. Procedure to update a student's marks
