STUDENT MANAGEMENT SYSTEM - SQL PRACTICE

Database: MySQL

Recommended execution order:
1. 01_create_database.sql
2. 02_create_tables.sql
3. 03_insert_students.sql
4. 04_insert_courses.sql
5. 05_insert_enrollments.sql
6. 06_basic_queries.sql
7. 07_join_queries.sql
8. 08_group_aggregate_queries.sql
9. 09_stored_procedures.sql
10. 10_practice_challenges.sql

This project practices:
- CREATE DATABASE
- CREATE TABLE
- PRIMARY KEY
- FOREIGN KEY
- INSERT
- SELECT
- WHERE
- ORDER BY
- UPDATE
- DELETE
- JOIN
- GROUP BY
- Aggregate functions
- Stored procedures
- CALL

Tip:
Run each file step by step in MySQL Workbench instead of importing everything at once.
