USE student_management;

INSERT INTO enrollments (student_id, course_id, marks)
VALUES
(1, 1, 85),
(1, 2, 90),
(2, 1, 78),
(2, 3, 82),
(3, 2, 95),
(3, 4, 88),
(4, 1, 91),
(4, 3, 89),
(5, 2, 75),
(5, 4, 80);
