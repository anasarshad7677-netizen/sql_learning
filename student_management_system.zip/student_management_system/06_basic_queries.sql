USE student_management;

-- View all students
SELECT * FROM students;

-- Find students from Lahore
SELECT * FROM students WHERE city = 'Lahore';

-- Find students older than 20
SELECT * FROM students WHERE age > 20;

-- Sort students by age
SELECT * FROM students ORDER BY age DESC;

-- Update a student's city
UPDATE students
SET city = 'Rawalpindi'
WHERE student_id = 2;

-- Delete a student
-- Run only if you want to practice DELETE.
-- DELETE FROM students WHERE student_id = 5;
