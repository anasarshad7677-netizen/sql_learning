USE student_management;

INSERT INTO students (name, email, age, gender, city)
VALUES
('Ali Khan', 'ali@gmail.com', 20, 'Male', 'Lahore'),
('Ahmed Raza', 'ahmed@gmail.com', 21, 'Male', 'Karachi'),
('Sara Ahmed', 'sara@gmail.com', 20, 'Female', 'Islamabad'),
('Ayesha Malik', 'ayesha@gmail.com', 22, 'Female', 'Lahore'),
('Usman Ali', 'usman@gmail.com', 21, 'Male', 'Multan');
