USE student_management;

-- Average marks for each course
SELECT
    courses.course_name,
    AVG(enrollments.marks) AS average_marks
FROM enrollments
JOIN courses
    ON enrollments.course_id = courses.course_id
GROUP BY courses.course_name;

-- Highest marks
SELECT MAX(marks) AS highest_marks
FROM enrollments;

-- Average marks
SELECT AVG(marks) AS average_marks
FROM enrollments;

-- Number of students
SELECT COUNT(*) AS total_students
FROM students;
