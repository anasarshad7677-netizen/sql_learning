USE student_management;

INSERT INTO courses (course_name, teacher)
VALUES
('Database Systems', 'Dr. Hassan'),
('Python Programming', 'Mr. Ahmed'),
('Artificial Intelligence', 'Dr. Bilal'),
('Web Development', 'Mr. Usman');
