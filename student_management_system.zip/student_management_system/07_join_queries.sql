USE student_management;

-- Show student name, course and marks
SELECT
    students.name,
    courses.course_name,
    enrollments.marks
FROM enrollments
JOIN students
    ON enrollments.student_id = students.student_id
JOIN courses
    ON enrollments.course_id = courses.course_id;
