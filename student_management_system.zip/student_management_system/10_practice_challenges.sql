USE student_management;

-- Try solving these without looking at the previous files.

-- 1. Find the student with the highest marks.

-- 2. Find the average marks of each student.

-- 3. Find how many students are enrolled in each course.

-- 4. Find students who scored more than 85.

-- 5. Find the course with the highest average marks.

-- 6. Create a procedure to find a student by student_id.

-- 7. Create a procedure to update a student's marks.
